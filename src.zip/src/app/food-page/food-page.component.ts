import { Component, OnInit } from '@angular/core';
import { FoodService } from '../services/food.service';
import { ActivatedRoute, Route, Router } from '@angular/router';
import { Food } from '../shared/model/food';
import { CartService } from '../services/cart.service';

@Component({
  selector: 'app-food-page',
  templateUrl: './food-page.component.html',
  styleUrls: ['./food-page.component.css']
})
export class FoodPageComponent implements OnInit {

        food!:Food| undefined;
  constructor(private api: FoodService, activateRoute: ActivatedRoute, private cartservice:CartService, private router: Router
    
  )
    {
          activateRoute.params.subscribe((params)=>{
            if(params.id)
               this.food= api.getFoodByID(params.id)

          });
}

    ngOnInit(): void {
      
    }

    addToCart(){
         
    
      if (this.food) {
        this.cartservice.addToCart(this.food);
        this.router.navigateByUrl('/cart-page');
      }
    }
}