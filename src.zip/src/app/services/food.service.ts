import { Injectable } from '@angular/core';
import { sample_foods, sample_tags } from 'src/data';
import { Food } from '../shared/model/food';
import { Tag } from '../shared/model/tag';

@Injectable({
  providedIn: 'root'
})
export class FoodService {

  constructor() { }

  getAllFoods(): Food[]
  {
      return sample_foods;
  }

  getFoodItem(searchItem: string){
     
       return this.getAllFoods().filter(food => food.name.toLowerCase().includes(searchItem.toLowerCase()));
  }
   
  getAllTags(): Tag[]
  {
      return sample_tags;

  }

   getSingleTag(tag: string) : Food[]{
      return tag=="All" ? this.getAllFoods()  : this.getAllFoods().filter( food => food.tags?.includes(tag) );
   }

   getFoodByID(fid : string)
   {
      return this.getAllFoods().find( food => food.id.toString()===fid);
   }
}
