import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class Serv1Service {

  apiurl="http://localhost:5000/users";
  constructor(private http: HttpClient) { }

  //adding data =>post()
  addUsers(data:any):Observable<any>
  {
     return this.http.post(this.apiurl,data);

  }

  //getting data =>get()
  getAllUsers():Observable<any>
  {
     return this.http.get(this.apiurl);

  }
  

}
