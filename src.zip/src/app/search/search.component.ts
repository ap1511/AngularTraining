import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit{

      searchItem1='';
      constructor(activateRoute: ActivatedRoute,private router: Router)
      {
           activateRoute.params.subscribe((params)=>{
               if(params.searchItem){
                 this.searchItem1=params.searchItem;
               }
           });
      }

      ngOnInit(): void {
        
      }

      search(item :string){
          if(item){
              this.router.navigateByUrl('/search/'+item);
          }
      }
}
