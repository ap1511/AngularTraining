import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Serv1Service } from '../services/serv1.service';
import { User } from '../shared/model/User';
import { Router } from '@angular/router';
import { BehaviorSubject, Observable } from 'rxjs';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit{
           loginForm!: FormGroup;
           isLogin=false;
           users1: User[] = [];
          
    //  private logSub: BehaviorSubject<boolean> = new BehaviorSubject(false);
    @Output() logSub= new EventEmitter<Boolean>;

           constructor( private fb: FormBuilder,private serv11: Serv1Service, private router:Router){
                    }
                  
             ngOnInit(): void {
              this.loginForm  = this.fb.group({
                email: ['', Validators.required, Validators.email],
                password: ['', Validators.required],
               
          
              }) 
}

submit(){
     if(this.loginForm.invalid){
      return;
     }
     else{
        console.log(this.loginForm.value);
           this.serv11.getAllUsers().subscribe((data)=>{
            console.log("in Log comp = "+JSON.stringify(data));

                this.users1 = data;

                 this.users1= this.users1.filter(u => (u.email === this.loginForm.value.email) && (u.password === this.loginForm.value.password));

                console.log(this.users1.length);
                if(this.users1.length > 0)
                  {
                     this.isLogin =true;
                     this.logSub.emit(true);
                  
                     console.log("login success");
                     this.router.navigateByUrl('/');
                  }
                 

           });
     }
}
// getBehSub():Observable<boolean>
// {
//    return this.logSub;
// }
}