export class Food //8 f1, f2
{
    id!:number;   //symbol so we have not to create constructor
    price!:number;
    name!:string;
    favourite!:boolean;
   // stars!:number;
    tags?:string[];
    imageUrl!:string;
    cookTime!:string;
    origins!:string[];
}