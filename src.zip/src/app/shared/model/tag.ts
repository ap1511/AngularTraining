export class Tag
{
    name!: string;
    count!:number;
}