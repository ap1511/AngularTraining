import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'zomato_clone';

  logSub!: boolean;

  getLog(bl : boolean)
  {
      this.logSub=nl;
  }
}
