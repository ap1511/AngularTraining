import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { User } from '../shared/model/User';
import { Serv1Service } from '../services/serv1.service';
import { Route, Router } from '@angular/router';

@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.css']
})
export class SignUPComponent {

  signForm!: FormGroup;
  isLogin=false;
  users1: User[] = [];
   

  constructor( private fb: FormBuilder,private serv11: Serv1Service, private router:Router){
           }
         
    ngOnInit(): void {
     this.signForm = this.fb.group({
       email: ['', Validators.required, Validators.email],
       password: ['', Validators.required],
      
 
     }) 
}

onFormSubmit(){
    if(this.signForm.invalid){
    return;
    }
    this.serv11.addUsers(this.signForm.value).subscribe({
      next: (val:any)=>{
         alert("User added successfully");
      
        
      },
      error: (err:any)=>{
           alert(err);
      }
    })
    
    }
}
