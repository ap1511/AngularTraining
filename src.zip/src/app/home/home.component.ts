import { Component, OnInit } from '@angular/core';
import { FoodService } from '../services/food.service';
import { Food } from '../shared/model/food';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent  implements OnInit {
      foods:Food[]=[];   
    
    constructor(private api: FoodService, activateRoute: ActivatedRoute)
    {
          activateRoute.params.subscribe((params)=>{
                if(params.searchItem)
                  this.foods = this.api.getFoodItem(params.searchItem)
                else if(params.tag)
                  this.foods=this.api.getSingleTag(params.tag)
                else
                this.foods=this.api.getAllFoods();
              }
            
          );

        
    }

    ngOnInit(): void {
      
    }
}
