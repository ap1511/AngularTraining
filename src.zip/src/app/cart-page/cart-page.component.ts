import { Component } from '@angular/core';
import { CartService } from '../services/cart.service';
import { Cart } from '../shared/model/Cart';
import { CartItem } from '../shared/model/CartItem';

@Component({
  selector: 'app-cart-page',
  templateUrl: './cart-page.component.html',
  styleUrls: ['./cart-page.component.css']
})
export class CartPageComponent {
      cart!:Cart;

    constructor(private cartSer :CartService){
          this.cartSer.getCartObservable().subscribe((cart)=>{
            this.cart = cart;
          })
    }

      removeFromCart1(cartItem : CartItem)
     {
          this.cartSer.removeFromCart(cartItem.food.id); 
     }
     
      changeQuant1(cartItem: CartItem, quantInString: string)
      {
            const quantity  =    parseInt(quantInString);                //string to int => parseInt()
            this.cartSer.changeQuantity(cartItem.food.id, quantity)
      }


}
